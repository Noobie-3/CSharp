﻿using MySqlConnector;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Duuuude
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        string myConnectionString = "server = localhost; database = library; uid = root; root pwd =; ";
        private void buttion1_Click(object sender, EventArgs e) {
            MySqlConnection cnn = new MySqlConnection(myConnectionString);
            cnn.Open();

            MySqlDataAdapter MyDA = new MySqlDataAdapter();
            string sqlSelectAll = "SELECT * from author";
            MyDA.SelectCommand = new MySqlCommand(sqlSelectAll, cnn);

            DataTable table = new DataTable();
            MyDA.Fill(table);

            BindingSource bSource = new BindingSource();
            bSource.DataSource = table;

            dataGridView1.DataSource = bSource;


        }
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e) { 
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }
    }
}
